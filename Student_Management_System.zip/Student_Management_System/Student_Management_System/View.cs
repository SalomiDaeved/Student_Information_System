﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management_System
{
    public partial class View : Form
    {
        public View()
        {
            InitializeComponent();
     

        }

       readonly SqlConnection Con = new SqlConnection(connectionString: @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Salomi\Documents\SMS.mdf; Integrated Security = True; Connect Timeout = 30");
        private void Fetchchemp()
        {
            try
            {
               Con.Open();
                string query = "select * from Student WHERE StuId='" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                DataTable dt=new DataTable();
                SqlDataAdapter sda=new SqlDataAdapter(cmd);
                sda.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {

                    label7.Text = dr["StuId"].ToString();
                    label9.Text = dr["StuName"].ToString();
                    label10.Text = dr["StuGen"].ToString();
                    label11.Text = dr["StuAdd"].ToString();
                    label12.Text = dr["StuPos"].ToString();
                    label14.Text = dr["StuDob"].ToString();
                    label16.Text = dr["StudPhone"].ToString();
                    label18.Text = dr["StudEdu"].ToString();

                    label7.Visible = true;
                    label9.Visible = true;
                    label10.Visible = true;
                    label11.Visible = true;
                    label12.Visible = true;
                    label14.Visible = true;
                    label16.Visible = true;
                    label18.Visible = true;














                }
                Con.Close();
            }

            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);

            }

           


        }  
    
       

        

        private void CrosBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
       

        private void Refreshbtn_Click(object sender, EventArgs e)
        {
            Fetchchemp();
        }

        private void Homebtn_Click(object sender, EventArgs e)
        {
            Home h= new Home();
            h.Show();
            this.Hide();
        }

        }
    }

