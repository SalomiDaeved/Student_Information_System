﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Password.UseSystemPasswordChar = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void CrosBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            Admin.Text = " ";
            Password.Text = " ";
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (Admin.Text == " " || Password.Text == " ")
            {
                MessageBox.Show("Missing Informatino");
            }
            else if (Admin.Text == "Admin" && Password.Text == "Student")
            {
                Home H = new Home();
                H.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Please Correct username amd password");
            }


        }

        private void Hide_CheckedChanged(object sender, EventArgs e)
        {

            if (Hidecheck.Checked == true)
            {

                Password.UseSystemPasswordChar = false;
            }

            else
            {
                Password.UseSystemPasswordChar = true;
            }






        }

       
    }
}