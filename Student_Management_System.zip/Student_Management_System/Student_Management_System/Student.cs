﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Student_Management_System
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
            DisplayStu();
        }
       readonly SqlConnection Con = new SqlConnection(connectionString: @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\Salomi\Documents\SMS.mdf; Integrated Security = True; Connect Timeout = 30");

        private void DisplayStu()
        {
            try
            {

                Con.Open();
                string Query = "select*from Student";
                SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                var ds = new DataSet();
                sda.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                Con.Close();














            }


            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }


            finally
            {
                Con.Close();
            }







        }





        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void Employee_Load(object sender, EventArgs e)
        {
            DisplayStu();
        }

        private void CrosBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }

        private void CrosBtn_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "")
                {

                    MessageBox.Show("Missing Information");

                }

                else
                {

                    Con.Open();
                    string query = "insert into Student values( '" + textBox1.Text + "', '" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox2.SelectedItem.ToString() + "','" + dateTimePicker1.Value.Date + "','" + textBox5.Text + "' ,'" + comboBox1.SelectedItem.ToString() + "','" + comboBox4.SelectedItem.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Enderd Successfully");
                    DisplayStu();



                }












            }


            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

            finally
            {
                Con.Close();
            }










        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "")
                {
                    MessageBox.Show("Ender The Student Id");
                }

                else
                {
                    Con.Open();

                    string query = "delete from Student WHERE StuId='" + textBox1.Text + "' ";
                  SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    Con.Close();
                    MessageBox.Show("Record Deleted Successfully ");
                    DisplayStu();


                }











            }


            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }

            finally
            {
                Con.Close();
            }





        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {

            textBox1.Text = " ";
            textBox2.Text = " ";
            comboBox1.Text = "";
            textBox3.Text = " ";
            comboBox2.Text = "";
            textBox5.Text = " ";
            comboBox4.Text = "";

        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            try
            {

                Con.Open();
                string query = "Update Student set StuId=@StuId, StuName=@StuName, StuAdd=@StuAdd,StuPos=@StuPos, StuDob=@StuDob,StudPhone=@StudPhone, StuGen=@StuGen, StudEdu=@StudEdu   WHERE StuId=@StuId";

                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.Parameters.AddWithValue("@StuName", textBox2.Text);
                cmd.Parameters.AddWithValue("@StuAdd", textBox3.Text);
                cmd.Parameters.AddWithValue("@StuPos", comboBox2.Text);
                cmd.Parameters.AddWithValue("@StuDob", dateTimePicker1.Value.Date);
                cmd.Parameters.AddWithValue("@StudPhone", textBox5.Text);
                cmd.Parameters.AddWithValue("@StuGen", comboBox1.Text);
                cmd.Parameters.AddWithValue("@StudEdu", comboBox4.Text);
                cmd.Parameters.AddWithValue("@StuId", textBox1.Text);
                cmd.ExecuteNonQuery();
                Con.Close();
                MessageBox.Show("Record Updated Successfully");
                DisplayStu();
            }


            catch (Exception Ex)
            {MessageBox.Show(Ex.Message);
            }

            finally { Con.Close(); }

        }
                





















           











            

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

            comboBox2.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
            comboBox4.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();


















        }



        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }
